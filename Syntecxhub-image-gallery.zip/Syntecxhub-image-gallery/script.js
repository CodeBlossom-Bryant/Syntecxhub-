const buttons = document.querySelectorAll('.filter');
const items = document.querySelectorAll('.gallery-item');
const toggle = document.querySelector('.filter-toggle');
const filters = document.querySelector('.filters');
buttons.forEach(button => button.addEventListener('click', () => {
  buttons.forEach(item => item.classList.remove('active'));
  button.classList.add('active');
  const category = button.dataset.filter;
  items.forEach(item => item.classList.toggle('hidden', category !== 'all' && !item.classList.contains(category)));
}));
toggle?.addEventListener('click', () => { const open = filters.classList.toggle('open'); toggle.setAttribute('aria-expanded', String(open)); toggle.querySelector('span').textContent = open ? '−' : '+'; });
